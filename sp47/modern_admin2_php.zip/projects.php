<?php include("includes/header.php"); ?>
<section class="glass">
  <?php include("includes/sidebar.php"); ?>
  <div class="games">
    <div class="status">
      <h1>My Projects</h1>
      <input type="text" placeholder="Search" />
    </div>
    <div class="projects cards">
      <div class="card">
        <img src="./images/assassins.png" alt="" />
        <div class="card-info">
          <h2>Assassins Creed</h2>
          <p>PS5 Version</p>
        </div>
      </div>
      <div class="card">
        <img src="./images/sackboy.png" alt="" />
        <div class="card-info">
          <h2>Sackboy A Great</h2>
          <p>PS5 Version</p>
        </div>
      </div>
      <div class="card">
        <img src="./images/spiderman.png" alt="" />
        <div class="card-info">
          <h2>Spiderman Miles</h2>
          <p>PS5 Version</p>
        </div>
      </div>
           <div class="card">
        <img src="./images/assassins.png" alt="" />
        <div class="card-info">
          <h2>Assassins Creed</h2>
          <p>PS5 Version</p>
        </div>
      </div>
      <div class="card">
        <img src="./images/sackboy.png" alt="" />
        <div class="card-info">
          <h2>Sackboy A Great</h2>
          <p>PS5 Version</p>
        </div>
      </div>
      <div class="card">
        <img src="./images/spiderman.png" alt="" />
        <div class="card-info">
          <h2>Spiderman Miles</h2>
          <p>PS5 Version</p>
        </div>
      </div>
           <div class="card">
        <img src="./images/assassins.png" alt="" />
        <div class="card-info">
          <h2>Assassins Creed</h2>
          <p>PS5 Version</p>
        </div>
      </div>
      <div class="card">
        <img src="./images/sackboy.png" alt="" />
        <div class="card-info">
          <h2>Sackboy A Great</h2>
          <p>PS5 Version</p>
        </div>
      </div>
      <div class="card">
        <img src="./images/spiderman.png" alt="" />
        <div class="card-info">
          <h2>Spiderman Miles</h2>
          <p>PS5 Version</p>
        </div>
      </div>
    </div>
  </div>
</section>
<?php include("includes/footer.php"); ?>