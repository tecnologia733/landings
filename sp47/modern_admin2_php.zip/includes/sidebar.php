  <div class="dashboard">
    <div class="user">
      <img src="./images/avatar.png" alt="img" />
      <h3>Ebraiz Ali</h3>
      <p>Pro Member</p>
    </div>
    <div class="links">
      <div class="link">
        <img src="./images/twitch.png" alt="img" />
        <a href="index.php">Dashboard</a>
      </div>
      <div class="link">
        <img src="./images/steam.png" alt="img" />
        <a href="projects.php">Projects</a>
      </div>
      <div class="link">
        <img src="./images/upcoming.png" alt="img" />
        <a href="listing.php">Product Listing</a>
      </div>
      <div class="link">
        <img src="./images/library.png" alt="img" />
        <a href="video.php">Video</a>
      </div>
    </div>
    <div class="pro">
      <h2>Join pro for free games.</h2>
      <img src="./images/controller.png" alt="img" />
    </div>
  </div>