<?php include("includes/header.php"); ?>
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="card card-plain">
          <div class="card-header">
            Google Maps
          </div>
          <div class="card-body">
            <div id="map" class="map"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php include("includes/footer.php"); ?>